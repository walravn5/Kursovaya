import sys
import sqlite3

from PyQt5 import QtCore, QtGui, QtWidgets
from PyQt5.QtWidgets import (
    QTableWidgetItem, 
    QStackedWidget
)

import clients
import Counters
import main_window
import Pay
import service
import login



class Expample(QtWidgets.QMainWindow, main_window.Ui_MainWindow):
    def __init__(self):
        super().__init__()
        self.setupUi(self)
        

class Login(QtWidgets.QMainWindow, login.Ui_MainWindow):
    def __init__(self):
        super().__init__()
        self.setupUi(self)
        self.pushButton.clicked.connect(self.test)

    def test(self):
        self.login=self.lineEdit.text()
        self.passwod=self.lineEdit_2.text()

        if self.login == "Administrator" and self.passwod == "Administrator":
            self.example = MainWindow()
            self.example.show()
            self.close()
        
        else:
             QtWidgets.QMessageBox.warning(self, "Ошибка", "Неправильный логин или пароль")




class Accidents(QtWidgets.QMainWindow,clients.Ui_MainWindow):
    def __init__(self):
        super().__init__()
        self.setupUi(self)
        self.Open.clicked.connect(self.test)
        self.Dell.clicked.connect(self.DellAccidents)
        self.Add.clicked.connect(self.AddAccidents)
        self.Change.clicked.connect(self.ChangeAccidents)

    def test(self):

        self.connection = sqlite3.connect("C:\\Users\\lovea\\OneDrive\\Документы\\Anton\\anton.db")
        self.cursor = self.connection.cursor()
        self.cursor.execute("SELECT * FROM 'Clients'")
        rows = self.cursor.fetchall()

        # получить список имен столбцов
        column_names = [i[0] for i in self.cursor.description]

        # добавить имена столбцов в первую строку таблицы
        self.tableWidget.setColumnCount(len(column_names))
        self.tableWidget.setRowCount(len(rows) + 1)
        for i, name in enumerate(column_names):
            item = QTableWidgetItem(name)
            self.tableWidget.setItem(0, i, item)

        # заполнить таблицу данными из запроса
        for i, row in enumerate(rows):
            for j, col in enumerate(row):
                item = QTableWidgetItem(str(col))
                self.tableWidget.setItem(i+1, j, item)

        self.connection.close()

    def DellAccidents(self):
           
        self.connection = sqlite3.connect("C:\\Users\\lovea\\OneDrive\\Документы\\Anton\\anton.db")
        self.cursor = self.connection.cursor()
        self.cursor.execute("DELETE FROM Clients WHERE client_id = ?", (self.DellLine.text(),))
        self.connection.commit()
        self.connection.close()
    
    def AddAccidents(self):
        self.connection = sqlite3.connect("C:\\Users\\lovea\\OneDrive\\Документы\\Anton\\anton.db")
        self.cursor = self.connection.cursor()
        self.cursor.execute("INSERT INTO Clients (first_name,last_name,address,phone,email) VALUES(?,?,?,?,?)", (self.AddLine.text(),self.AddLine_2.text(),self.AddLine_3.text(),self.AddLine_4.text(),self.AddLine_5.text()))
        self.connection.commit()
        self.connection.close()


    def ChangeAccidents(self):
        self.connection = sqlite3.connect("C:\\Users\\lovea\\OneDrive\\Документы\\Anton\\anton.db")
        self.cursor = self.connection.cursor()
        self.cursor.execute(f"UPDATE Clients SET first_name='{self.ChangeLine_2.text()}', last_name='{self.ChangeLine_3.text()}', address={self.ChangeLine_4.text()}, phone={self.ChangeLine_5.text()}, email = {self.ChangeLine_6.text()} WHERE client_id='{self.ChangeLine.text()}'")


        self.connection.commit()
        self.connection.close()

class Drivers(QtWidgets.QMainWindow,Counters.Ui_MainWindow):
    def __init__(self):
        super().__init__()
        self.setupUi(self)

        self.Open.clicked.connect(self.test)
        self.Dell.clicked.connect(self.DellDrivers)
        self.Add.clicked.connect(self.AddDrivers)
        self.Change.clicked.connect(self.ChangeDrivers)
        
        
    
    def test(self):
        self.connection = sqlite3.connect("C:\\Users\\lovea\\OneDrive\\Документы\\Anton\\anton.db")
        self.cursor = self.connection.cursor()
        self.cursor.execute("SELECT * FROM 'Counters'")
        rows = self.cursor.fetchall()

        # получить список имен столбцов
        column_names = [i[0] for i in self.cursor.description]

        # добавить имена столбцов в первую строку таблицы
        self.tableWidget.setColumnCount(len(column_names))
        self.tableWidget.setRowCount(len(rows) + 1)
        for i, name in enumerate(column_names):
            item = QTableWidgetItem(name)
            self.tableWidget.setItem(0, i, item)

        # заполнить таблицу данными из запроса
        for i, row in enumerate(rows):
            for j, col in enumerate(row):
                item = QTableWidgetItem(str(col))
                self.tableWidget.setItem(i+1, j, item)

        self.connection.close()
    
    def DellDrivers(self):
        self.connection = sqlite3.connect("C:\\Users\\lovea\\OneDrive\\Документы\\Anton\\anton.db")
        self.cursor = self.connection.cursor()
        self.cursor.execute("DELETE FROM Counters WHERE counter_id =?", (self.DellLine.text(),))
        self.connection.commit()
        self.connection.close()

    def AddDrivers(self):
        self.connection = sqlite3.connect("C:\\Users\\lovea\\OneDrive\\Документы\\Anton\\anton.db")
        self.cursor = self.connection.cursor()
        self.cursor.execute("INSERT INTO 'Counters' (client_id,service_id,readings,reading_date) VALUES (?,?,?,?)",
                       (self.AddLine.text(),self.AddLine_2.text(),self.AddLine_3.text(),self.AddLine_4.text()))
                           
        self.connection.commit()
        self.connection.close()


    def ChangeDrivers(self):
        self.connection = sqlite3.connect("C:\\Users\\lovea\\OneDrive\\Документы\\Anton\\anton.db")
        self.cursor = self.connection.cursor()
        self.cursor.execute(f"UPDATE Counters SET client_id='{self.ChangeLine_2.text()}', service_id='{self.ChangeLine_3.text()}', readings={self.ChangeLine_4.text()}, reading_date='{self.ChangeLine_5.text()}' WHERE counter_id='{self.ChangeLine.text()}'")

        
        self.connection.commit()
        self.connection.close()

class Fuel(QtWidgets.QMainWindow,Pay.Ui_MainWindow):
    def __init__(self):
        super().__init__()
        self.setupUi(self)
        self.Open.clicked.connect(self.test)
        self.Dell.clicked.connect(self.DellFuel)
        self.Add.clicked.connect(self.AddFuel)
        self.Change.clicked.connect(self.ChangeFuel)
        

    def test(self):
        self.connection = sqlite3.connect("C:\\Users\\lovea\\OneDrive\\Документы\\Anton\\anton.db")
        self.cursor = self.connection.cursor()
        self.cursor.execute("SELECT * FROM 'Payments'")
        rows = self.cursor.fetchall()

        # получить список имен столбцов
        column_names = [i[0] for i in self.cursor.description]

        # добавить имена столбцов в первую строку таблицы
        self.tableWidget.setColumnCount(len(column_names))
        self.tableWidget.setRowCount(len(rows) + 1)
        for i, name in enumerate(column_names):
            item = QTableWidgetItem(name)
            self.tableWidget.setItem(0, i, item)

        # заполнить таблицу данными из запроса
        for i, row in enumerate(rows):
            for j, col in enumerate(row):
                item = QTableWidgetItem(str(col))
                self.tableWidget.setItem(i+1, j, item)

        self.connection.close()

    def DellFuel(self):
        self.connection = sqlite3.connect("C:\\Users\\lovea\\OneDrive\\Документы\\Anton\\anton.db")
        self.cursor = self.connection.cursor()
        self.cursor.execute("DELETE FROM Payments WHERE payment_id =?", (self.DellLine.text(),))
        self.connection.commit()
        self.connection.close()

    def AddFuel(self):

        self.connection = sqlite3.connect("C:\\Users\\lovea\\OneDrive\\Документы\\Anton\\anton.db")
        self.cursor = self.connection.cursor()
        self.cursor.execute("INSERT INTO Payments (client_id,service_id,payment_date,amount) VALUES(?,?,?,?)", (self.AddLine.text(), self.AddLine_2.text(),self.AddLine_3.text(),self.AddLine_4.text()))
        self.connection.commit()
        self.connection.close()


    def ChangeFuel(self):
        self.connection = sqlite3.connect("C:\\Users\\lovea\\OneDrive\\Документы\\Anton\\anton.db")
        self.cursor = self.connection.cursor()
        self.cursor.execute(f"UPDATE Payments SET client_id='{self.ChangeLine.text()}', service_id='{self.ChangeLine_2.text()}', payment_date='{self.ChangeLine_3.text()}', amount ={self.ChangeLine_3.text()} WHERE payment_id='{self.ChangeLine.text()}'")

        self.connection.commit()
        self.connection.close()


class Inspection(QtWidgets.QMainWindow,service.Ui_MainWindow):
    def __init__(self):
        super().__init__()
        self.setupUi(self)
        self.Open.clicked.connect(self.test1)
        self.Dell.clicked.connect(self.DellInspection)
        self.Add.clicked.connect(self.AddInspection)
        self.Change.clicked.connect(self.ChangeInspection)


    def test1(self):
        
        self.connection = sqlite3.connect("C:\\Users\\lovea\\OneDrive\\Документы\\Anton\\anton.db")
        self.cursor = self.connection.cursor()
        self.cursor.execute("SELECT * FROM 'Services'")
        rows = self.cursor.fetchall()

        # получить список имен столбцов
        column_names = [i[0] for i in self.cursor.description]

        # добавить имена столбцов в первую строку таблицы
        self.tableWidget.setColumnCount(len(column_names))
        self.tableWidget.setRowCount(len(rows) + 1)
        for i, name in enumerate(column_names):
            item = QTableWidgetItem(name)
            self.tableWidget.setItem(0, i, item)

        # заполнить таблицу данными из запроса
        for i, row in enumerate(rows):
            for j, col in enumerate(row):
                item = QTableWidgetItem(str(col))
                self.tableWidget.setItem(i+1, j, item)

        self.connection.close()
    
    def DellInspection(self):
        self.connection = sqlite3.connect("C:\\Users\\lovea\\OneDrive\\Документы\\Anton\\anton.db")
        self.cursor = self.connection.cursor()
        self.cursor.execute("DELETE FROM Services WHERE service_id =?", (self.DellLine.text(),))
        self.connection.commit()
        self.connection.close()



    def AddInspection(self):

        self.connection = sqlite3.connect("C:\\Users\\lovea\\OneDrive\\Документы\\Anton\\anton.db")
        self.cursor = self.connection.cursor()
        self.cursor.execute("INSERT INTO Services (name,description,cost) VALUES(?,?,?)", (self.AddLine.text(), self.AddLine_2.text(),self.AddLine_3.text(),))
        self.connection.commit()
        self.connection.close()

    def ChangeInspection(self):
        
        self.connection = sqlite3.connect("C:\\Users\\lovea\\OneDrive\\Документы\\Anton\\anton.db")
        self.cursor = self.connection.cursor()
        self.cursor.execute(f"UPDATE Services SET name='{self.ChangeLine_2.text()}', description='{self.ChangeLine_3.text()}', cost='{self.ChangeLine_4.text()}' WHERE service_id='{self.ChangeLine.text()}'")

        self.connection.commit()
        self.connection.close()




class MainWindow(QtWidgets.QMainWindow):
    def __init__(self):
        super().__init__()
        self.stacked_widget = QStackedWidget()
        self.setCentralWidget(self.stacked_widget)



        self.example = Expample()
        self.accidents = Accidents()
        self.drivers = Drivers()
        self.fuel = Fuel()
        self.inspection = Inspection()
        

        self.stacked_widget.addWidget(self.example)
        self.stacked_widget.addWidget(self.accidents)
        self.stacked_widget.addWidget(self.drivers)
        self.stacked_widget.addWidget(self.fuel)
        self.stacked_widget.addWidget(self.inspection)
        
    

        self.example.AccidentsBtn.clicked.connect(self.show_accidents)
        self.accidents.Back.clicked.connect(self.show_example)
        self.example.DriversBtn.clicked.connect(self.show_drivers)
        self.drivers.Back.clicked.connect(self.show_example)
        self.example.FuelBtn.clicked.connect(self.show_fuel)
        self.fuel.Back.clicked.connect(self.show_example)
        self.example.InspectionsBtn.clicked.connect(self.show_inspection)
        self.inspection.Back.clicked.connect(self.show_example)
        
        
        

    def show_example(self):
        self.stacked_widget.setCurrentWidget(self.example)

    def show_accidents(self):
        self.stacked_widget.setCurrentWidget(self.accidents)
    
    def show_drivers(self):
        self.stacked_widget.setCurrentWidget(self.drivers)
    
    def show_fuel(self):
        self.stacked_widget.setCurrentWidget(self.fuel)

    def show_inspection(self):
        self.stacked_widget.setCurrentWidget(self.inspection)
    


if __name__ == "__main__":
    app = QtWidgets.QApplication(sys.argv)
    window = Login()
    window.show()
    sys.exit(app.exec_())

